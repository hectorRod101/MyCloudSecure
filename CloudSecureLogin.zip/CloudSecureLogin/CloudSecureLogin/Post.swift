//
//  Post.swift
//  CloudSecureLogin
//
//  Created by Hector Rodriguez on 12/12/19.
//  Copyright © 2019 Hector Rodriguez. All rights reserved.
//

import Foundation

struct Post{
    let postID: String
    let firstName: String
    let lastName: String
    let email: String
    let phoneNumber: String
    let password: String
}
