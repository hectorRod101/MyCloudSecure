//
//  DatabaseService.swift
//  CloudSecureLogin
//
//  Created by Hector Rodriguez on 12/12/19.
//  Copyright © 2019 Hector Rodriguez. All rights reserved.
//

import Foundation
import Firebase

class DatabaseService{
    static let shared = DatabaseService()
    private init(){}
    
    let ref = Database.database().reference().child("users")
}
