//
//  VerifyController.swift
//  CloudSecureLogin
//
//  Created by Hector Rodriguez on 12/12/19.
//  Copyright © 2019 Hector Rodriguez. All rights reserved.
//

import UIKit

class VerifyController: UIViewController{
    @IBOutlet weak var VerifyText: UITextField!
    
    @IBAction func CodeVerify(_ sender: Any) {
      
        }
}
 
