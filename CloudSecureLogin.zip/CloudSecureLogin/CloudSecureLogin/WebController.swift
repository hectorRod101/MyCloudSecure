//
//  WebController.swift
//  CloudSecureLogin
//
//  Created by Hector Rodriguez on 12/5/19.
//  Copyright © 2019 Hector Rodriguez. All rights reserved.
//

import UIKit
import WebKit
class WebController: UIViewController, WKUIDelegate {
    
    var webView: WKWebView!
    
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let myURL = URL(string:"http://mycloudsecure-env.ytsvvhm3cx.us-west-2.elasticbeanstalk.com")
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)
    }}


