//
//  RegisterController.swift
//  CloudSecureLogin
//
//  Created by Hector Rodriguez on 12/4/19.
//  Copyright © 2019 Hector Rodriguez. All rights reserved.
//

import SwiftUI
import Firebase
import WebKit

class RegisterController: UIViewController, UITextFieldDelegate{
    
    //var ref: DatabaseReference!
    //var ref = Database.database().reference()
    
    var posts = [Post]()
    
    @IBOutlet weak var textFieldStackView: UIStackView!
    
    // First Name textfield
    @IBOutlet weak var FirstName: UITextField!
    
    // Laset Name textfield
    @IBOutlet weak var LastName: UITextField!
    
    // Email Address textfield
    @IBOutlet weak var Email: UITextField!
    
    // Phone Number textfield
    @IBOutlet weak var PhoneNumber: UITextField!
    
    // Password textfield
    @IBOutlet weak var Password: UITextField!
    
    // Confirmation password textfield
    @IBOutlet weak var PasswordConfirm: UITextField!
    
    
    @IBOutlet weak var RegisterButton: RoundButton!
    
    @IBOutlet weak var passConMessage: UILabel!
    
    @IBOutlet weak var emailMessage: UILabel!
    
    override func viewDidLoad() {
            super.viewDidLoad()
        // Do any additional setup after loading the view
        FirstName.delegate = self
        LastName.delegate = self
        Email.delegate = self
        PhoneNumber.delegate = self
        Password.delegate = self
        PasswordConfirm.delegate = self
        
        // Add quick delete text to TextFields
        FirstName.clearButtonMode = UITextField.ViewMode.whileEditing
        LastName.clearButtonMode = UITextField.ViewMode.whileEditing
        Email.clearButtonMode = UITextField.ViewMode.whileEditing
        PhoneNumber.clearButtonMode = UITextField.ViewMode.whileEditing
        Password.clearButtonMode = UITextField.ViewMode.whileEditing
        PasswordConfirm.clearButtonMode = UITextField.ViewMode.whileEditing
        
        emailMessage.isHidden = true
        passConMessage.isHidden = true

         
        // tap user input of screen and return key
        configureTapGesture()
        
        // setupAddTargetIsNotEmptyTextFields()
        RegisterButton.isEnabled = false

        [FirstName, LastName, Email, PhoneNumber, Password, PasswordConfirm].forEach({ $0.addTarget(self, action: #selector(editingChanged), for: .editingChanged) })
        
        // Textfield listens to user input therefore changing background color
        [FirstName, LastName, Email, PhoneNumber, Password, PasswordConfirm].forEach({ $0.addTarget(self, action: #selector(editingTextboxChanged), for: .editingChanged) })
        
        
        [Password, PasswordConfirm].forEach({ $0.addTarget(self, action: #selector(editTextPassword(textField:)), for: .editingChanged) })
        
        
        // Listen for the keyboard
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        }
    
    // Stop listening to keyboard hide/show events
    deinit {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)    }
    
    
    // Display keyboard when textfield tapped
    @objc func keyboardWillShow(notification:NSNotification){
        view.frame.origin.y = -220
    }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
 
        // function: takes user tap input and
        // configures keyboard to appear and disappear
        private func configureTapGesture(){
            let tapGesture = UITapGestureRecognizer(target: self, action:#selector(ViewController.handleTap))
            view.addGestureRecognizer(tapGesture)
        }
        
        // function: handles user input tap
        @objc func handleTap(){
            print("Handle tap was called")
            UIView.animate(withDuration: 0.30,
                delay: 0.0,
                options: .curveEaseIn,
                animations: {
                    self.view.frame.origin.y = 0
            },
                           completion: nil)
            view.endEditing(true)
        }
        
    // Format phone number
    private func textFieldPhone(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool
    {
        if (textField == PhoneNumber) {
            let newString = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            let components = newString.components(separatedBy: NSCharacterSet.decimalDigits.inverted)

            let decimalString = components.joined(separator: "") as NSString
            let length = decimalString.length
            let hasLeadingOne = length > 0 && decimalString.hasPrefix("1")

            if length == 0 || (length > 10 && !hasLeadingOne) || length > 11 {
                let newLength = (textField.text! as NSString).length + (string as NSString).length - range.length as Int

                return (newLength > 10) ? false : true
            }
            var index = 0 as Int
            let formattedString = NSMutableString()

            if hasLeadingOne {
                formattedString.append("1 ")
                index += 1
            }
            if (length - index) > 3 {
                let areaCode = decimalString.substring(with: NSMakeRange(index, 3))
                formattedString.appendFormat("(%@)", areaCode)
                index += 3
            }
            if length - index > 3 {
                let prefix = decimalString.substring(with: NSMakeRange(index, 3))
                formattedString.appendFormat("%@-", prefix)
                index += 3
            }

            let remainder = decimalString.substring(from: index)
            formattedString.append(remainder)
            textField.text = formattedString as String
            print("Phone formated")

            return false
        }
        else {
            print("Phone formated")
            return true
        }
    }
    
    // Return screen to normal when Login Button tapped
    @IBAction func LoginButtonReturn(_ sender: Any) {
        view.frame.origin.y = 0
    }
    
    @IBAction func registerButtonDone(_ sender: UIButton) {
        
        guard let emailAddress = self.Email.text
        else{
            print("Invalid input")
            return
        }
        
        UIView.animate(withDuration: 0.0,
            delay: 0.0,
            options: .curveEaseIn,
            animations: {
                self.view.frame.origin.y = 0
        },
                       completion: nil)
        
        Auth.auth().fetchSignInMethods(forEmail: emailAddress, completion: {(User, Error) in
            if Error != nil{
                print(Error!)
                print("Valid Credentials")
                
            }
        })
    }
    
    @IBAction func RegisterButton(_ sender: UIButton) {
        
        guard let email = self.Email.text, let password = self.Password.text, let phoneNumber = PhoneNumber.text
        else{
            print("Invalid input")
            return
        }
        
        Auth.auth().createUser(withEmail: email, password: password, completion: {(User, Error) in
            if Error != nil{
                print(Error!)
                print("Valid Credentials")
                
                return
            }
            
            UIView.animate(withDuration: 0.0,
                               delay: 0.0,
                               options: .curveEaseIn,
                               animations: {
                                   self.view.frame.origin.y = 0
                           },
                                          completion: nil)
            
            self.performSegue(withIdentifier: "RegisterComplete", sender: self)
            
        })
        
        
        let parameters = ["firstName"   :   "Test",
                          "lastName"    :   "Test",
                          "email"       :   "Test@gmail.com",
                          "phoneNumber" :   "+1 714-225-0026",
                          "password"    :   "password"
        ]
        
        DatabaseService.shared.ref.childByAutoId().setValue(parameters)
        
        
    }
    
    
    @objc func editingTextboxChanged(_ textField: UITextField) {
           if textField.text?.count == 1 {
               if textField.text?.first == " " {
                   textField.text = ""
                   return
               }
           }

           guard
               let emailAdd = textField.text, !emailAdd.isEmpty
               else {
                   textField.backgroundColor = UIColor(red: 33/255, green: 79/255, blue: 160/255, alpha: 1)
                   return
               }
           textField.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
       }
    
    
    
    @objc func editTextPassword( textField: UITextField){
         if textField.text?.count == 1 {
                   if textField.text?.first == " " {
                       textField.text = ""
                       return
                   }
               }
        
        
        guard
        let passwordCon = PasswordConfirm.text, !passwordCon.isEmpty,
            let password = Password.text, !password.isEmpty,
                passwordCon == password
            else {
                passConMessage.isHidden = false
                return
            }
        passConMessage.isHidden = true

    }
    
    
    
    @objc func editingChanged(_ textField: UITextField) {
        if textField.text?.count == 1 {
            if textField.text?.first == " " {
                textField.text = ""
                return
            }
        }
        
        guard
            let first = FirstName.text, !first.isEmpty,
            let last = LastName.text, !last.isEmpty,
            let emailAdd = Email.text, !emailAdd.isEmpty,
            let phone = PhoneNumber.text, !phone.isEmpty,
            let password = Password.text, !password.isEmpty,
            let passwordCon = PasswordConfirm.text, password == passwordCon
        else {
            self.RegisterButton.isEnabled = false
            self.RegisterButton.backgroundColor = UIColor(red: 178/255, green: 210/255, blue: 237/255, alpha: 1)
            return
        }
        self.RegisterButton.isEnabled = true
        self.RegisterButton.backgroundColor = UIColor(red: 33/255, green: 79/255, blue: 160/255, alpha: 1)
    }
    
}

   
