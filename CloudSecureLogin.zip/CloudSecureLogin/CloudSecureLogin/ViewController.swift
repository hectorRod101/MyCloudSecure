//
//  ViewController.swift
//  CloudSecureLogin
//
//  Created by Hector Rodriguez on 11/27/19.
//  Copyright © 2019 Hector Rodriguez. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    // E-Mail textfield
    @IBOutlet weak var EMail: UITextField!
    
    // Password textfield
    @IBOutlet weak var Password: UITextField!
    
    //@IBOutlet weak var LoginButton: RoundButton!
    @IBOutlet weak var validMessage: UILabel!
    
    //@IBOutlet weak var RegisterButton: RoundButton!
    @IBOutlet weak var loginButton: RoundButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Enable Textfields to instantly clear text by proving 'x' button
        EMail.clearButtonMode = UITextField.ViewMode.whileEditing
        Password.clearButtonMode = UITextField.ViewMode.whileEditing
        
        // Hide message
        validMessage.isHidden = true
        
        // Disable Login button
        loginButton.isEnabled = false
        
        // Set image inside EMail TextField
        let accountImage = UIImage(named:"account")
        addLeftImageTo(txtField: EMail, andImage: accountImage!)
        
       // Set image inside Password TextField
        let passwordImage = UIImage(named:"lock")
        addLeftImageTo(txtField: Password, andImage: passwordImage!)
        
        // Check if all fields are inputted to enable Login button
        [EMail, Password].forEach({ $0.addTarget(self, action: #selector(editingChanged), for: .editingChanged) })
        
        // Textfield listens to user input therefore changing background color
        [EMail, Password].forEach({ $0.addTarget(self, action: #selector(editingTextboxChanged), for: .editingChanged) })
        
        // configure delegates
        configureTextFields()
        
        // tap user input of screen and return key
        configureTapGesture()
    }
    
    
    
    // Function
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    // Function: Add image to the right side of TextField
    //          txtField - Given TextField to display image
    //          andImage - Image being displayed
    func addLeftImageTo(txtField: UITextField, andImage img: UIImage){
        let imageView = UIImageView(frame: CGRect(x: 0.0, y: -7, width: 40.0, height: 40.0))
        let image = img
        imageView.image = image
        imageView.contentMode = .scaleAspectFit

        let view = UIView(frame: CGRect(x: 0, y: -9, width: 32, height: 40))
        view.addSubview(imageView)
        txtField.leftViewMode = .always
        txtField.leftView = view
    }

    // function: takes user tap input and
    // configures keyboard to appear and disappear
    private func configureTapGesture(){
        let tapGesture = UITapGestureRecognizer(target: self, action:#selector(ViewController.handleTap))
        view.addGestureRecognizer(tapGesture)
    }
    
    
    // function: handles user input tap
    @objc func handleTap(){
        print("Handle tap was called")
        view.endEditing(true)
    }
    
    
    // configures textfield delegates
    private func configureTextFields(){
        EMail.delegate = self
        Password.delegate = self
    }
    
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        for URLContext in URLContexts {
            let url = URLContext.url
            Auth.auth().canHandle(url)
        }
    }
    
    // Button Login
    @IBAction func LoginConfirm(_ sender: UIButton) {
        
        if let email = EMail.text,
            let pass = Password.text
        {
            Auth.auth().signIn(withEmail: email, password: pass) { (user, error) in
                
                // Check if it is a valid user
                if user != nil{
                    // Hide message
                    self.validMessage.isHidden = true
                    self.performSegue(withIdentifier: "goToSecondAuth", sender: self)
                }
                else{
                    // Hide message
                    self.validMessage.text = "The username or password you entered is incorrect."
                    self.validMessage.isHidden = false
                }
            }
        
        }
        
        
        
    }
    
    
    // Create User
    func CreateUser(){
    }
    
    
    //
    @objc func editingChanged(_ textField: UITextField) {
        if textField.text?.count == 1 {
            if textField.text?.first == " " {
                textField.text = ""
                return
            }
        }
        guard
            let emailAdd = EMail.text, !emailAdd.isEmpty,
            let password = Password.text, !password.isEmpty
        else {
            self.loginButton.isEnabled = false
            self.loginButton.backgroundColor = UIColor(red: 178/255, green: 210/255, blue: 237/255, alpha: 1)
            return
        }
        self.loginButton.isEnabled = true
        self.loginButton.backgroundColor = UIColor(red: 33/255, green: 79/255, blue: 160/255, alpha: 1)
    }

    @objc func editingTextboxChanged(_ textField: UITextField) {
        if textField.text?.count == 1 {
            if textField.text?.first == " " {
                textField.text = ""
                return
            }
        }

        guard
            let emailAdd = textField.text, !emailAdd.isEmpty
            else {
                textField.backgroundColor = UIColor(red: 33/255, green: 79/255, blue: 160/255, alpha: 1)
                return
            }
        
        textField.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
    }

    // User Sign-In
    func signInUser(email: String, password: String){
        Auth.auth().signIn(withEmail: email, password: password) {(user, Error)
            in
            if Error == nil{
                self.validMessage.isHidden = false
                self.validMessage.text = "Success Login"
                print("success login")
                
            } else if (Error?._code  == AuthErrorCode.userNotFound.rawValue){
                self.validMessage.isHidden = false
                self.validMessage.text = "Sorry, couldn't find your MyCloud Account"
            }
            else{
                print("Not a user")
                self.validMessage.isHidden = false
                self.validMessage.text = "Sorry, couldn't find your MyCloud Account"
               // print(Error)
               // print(Error?.localizedDescription)
            }
        }
    }
    
}

extension ViewController:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

